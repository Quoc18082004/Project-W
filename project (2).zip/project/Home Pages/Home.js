$(document).ready(function(){
    $('.pet-slider').slick({
        infinite: true, // Vòng lặp vô tận
        slidesToShow: 3, // Hiển thị 3 thẻ cùng lúc
        slidesToScroll: 1, // Cuộn 1 thẻ mỗi lần
        arrows: true, // Hiển thị nút mũi tên
        dots: true, // Hiển thị chấm chỉ số
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('open');
    });
});